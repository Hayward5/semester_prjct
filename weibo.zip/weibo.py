import scrapy
from urllib.parse import urljoin
from crawlerv3.settings import SELENIUM_DRIVER_EXECUTABLE_PATH
from crawlerv3.items import *
from crawlerv3.plugins.dateProcess import *
from crawlerv3.plugins.extractorProcess import pre_proc_data
from selenium import webdriver
import json

class WeiboSpiderByUser(scrapy.Spider):
    name = "weibo-by-user"
    allowed_domains = ['m.weibo.cn']
    start_urls = ['https://m.weibo.cn']

    custom_settings = {
        'ITEM_PIPELINES': {
            'crawlerv3.pipelines.MongoDBPipeline': 802
        },
        'DOWNLOADER_MIDDLEWARES': {
            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'crawlerv3.middlewares.RandomUserAgentMiddleware': 500,            
            'crawlerv3.rotating_free_proxies.middlewares.RotatingProxyMiddleware': 610,
            'crawlerv3.rotating_free_proxies.middlewares.BanDetectionMiddleware': 620,
        },
        'REFERER_ENABLED': True,
        'RETRY_TIMES': 5,
        'DOWNLOAD_DELAY': 10,
        'CONCURRENT_REQUESTS': 5,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 3
    }

    def __init__(self, *args, **kwargs):
        super(WeiboSpiderByUser, self).__init__(*args, **kwargs)
        self.weibo_uids = [
            "2656274875", "7483054836", "7468777622", "7723679954",
            "7468777622", "7336594039", "6439298407", "6189120710"
            ]
        # self.weibo_uids = ["2810373291"]
        self.follow_url = 'https://m.weibo.cn/api/container/getIndex?containerid=231051_-_followers_-_{uid}&page={page}'
        self.user_url = 'https://m.weibo.cn/api/container/getIndex?uid={uid}&type=uid&value={uid}&containerid=100505{uid}'
        self.weibo_url = 'https://m.weibo.cn/api/container/getIndex?uid={uid}&type=uid&page={page}&containerid=107603{uid}'
    
    def start_requests(self):
        for weibo_uid in self.weibo_uids:
            self.logger.info('start crawl: %s' % (self.weibo_url.format(uid=weibo_uid, page=1)))
            yield scrapy.Request(
                url=self.user_url.format(uid=weibo_uid, page=1), 
                callback=self.parse_user,
                dont_filter=True, meta={'uid': weibo_uid}
            )

    def parse_user(self, response):
            """
            解析用户信息
            :param response: Response对象
            """
            item = WeiboItem()
            item['uid'] = response.meta.get('uid')
            try:
                result = json.loads(response.text)
                if 'data' in result and 'userInfo' in result['data']:
                    item['title'] = u"%s 的發文" % (result['data']['userInfo']['screen_name'])
                yield scrapy.Request(
                    url=self.weibo_url.format(uid=item['uid'], page=1), 
                    callback=self.parse_weibos,
                    dont_filter=True, meta={'item': item}
                )
            except json.JSONDecodeError:
                self.logger.warning(msg=f'json decode error. ({response.url}) text: {response.text[:500]}')
            except Exception as e:
                self.logger.warning(msg=e)

    def parse_weibos(self, response):
            """
            解析微博列表
            :param response: Response 对象
            """
            item = response.meta['item']
            try:
                result = json.loads(response.text)
                if result.get('ok') and 'data' in result and 'cards' in result['data']:
                    weibos = result.get('data').get('cards')
                    for weibo in weibos:
                        mblog = weibo.get('mblog')
                        if mblog:
                            weibo_raw_item = {}
                            field_map = {
                                'id': 'id', 'attitudes_count': 'attitudes_count', 'comments_count': 'comments_count',
                                'reposts_count': 'reposts_count', 'picture': 'original_pic', 'pictures': 'pics',
                                'created_at': 'created_at', 'source': 'source', 'text': 'text', 'raw_text': 'raw_text',
                                'thumbnail': 'thumbnail_pic',
                            }
                            for field, attr in field_map.items():
                                weibo_raw_item[field] = mblog.get(attr)
                            
                            # 對應情資平台欄位
                            extract_date = timestamp_convertor(weibo_raw_item['created_at'])
                            item['date'] = extract_date
                            item['link'] = urljoin("https://m.weibo.cn/detail/", weibo_raw_item['id'])
                            item['content'] = pre_proc_data(content=weibo_raw_item['text'])            
                            yield item
            except json.JSONDecodeError:
                self.logger.warning(msg=f'json decode error. ({response.url}) text: {response.text[:500]}')
            except Exception as e:    
                self.logger.warning(msg=e)

    def response_is_ban(self, request, response):
        # 如果 RESPONSE 包含 'REQUEST_METHOD' 或 'HTTP_USER-AGENT'，判定為被封鎖
        if (b'REQUEST_METHOD' in response.body and b'HTTP_USER-AGENT' in response.body) or response.status == 403:
            return True
        else:
            return False

    def exception_is_ban(self, request, exception):
        return None
